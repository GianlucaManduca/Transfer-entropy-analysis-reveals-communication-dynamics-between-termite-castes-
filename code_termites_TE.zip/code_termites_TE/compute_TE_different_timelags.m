%% TRANSFER ENTROPY ANALYSIS ACROSS TIME LAGS
% Author: Gianluca Manduca
% Description: This script computes the transfer entropy between two signals (X1 and Y1)
%              for a range of time lags (τ_x and τ_y) in both directions.
%              The goal is to identify the time lag combination that maximizes information transfer.

clear; close all; clc;

%% === LOAD DATA ===
% Choose between velocity or area data
% Uncomment the desired dataset
load data_optimal/area.mat  % Area data
% load data_optimal/speed.mat   % Speed data


% The matrices X1 and Y1 should have dimensions [trials x timepoints]

%% === GROUP DESCRIPTION ===
% The dataset includes 27 trials divided into three groups:
% - Group 1: trials 1 to 9
% - Group 2: trials 10 to 18
% - Group 3: trials 19 to 27

% You can manually select the group to analyze by specifying the corresponding trial indices.
% For example: range = 10:18; % (Group 2)

%% === INITIALIZE PARAMETERS ===
max_lag = 50;                % Maximum time lag for both τ_x and τ_y
n_trials = size(X1,1);       % Number of trials (should be 27)

% Preallocate 3D matrices: [τ_x, τ_y, trial]
Transfer_XY = zeros(max_lag, max_lag, n_trials);  % X → Y
Transfer_YX = zeros(max_lag, max_lag, n_trials);  % Y → X

fprintf('Computing transfer entropy over time lag combinations (τ_x, τ_y)...\n');

%% === COMPUTE TRANSFER ENTROPY FOR EACH TIME LAG COMBINATION ===
for T_X = 1:max_lag
    fprintf('Processing τ_x = %d/%d\n', T_X, max_lag);
    for T_Y = 1:max_lag
        for i = 1:n_trials
            % Compute transfer entropy in both directions
            Transfer_XY(T_X, T_Y, i) = transferEntropyPartition(X1(i,:), Y1(i,:), T_X, T_Y);
            Transfer_YX(T_X, T_Y, i) = transferEntropyPartition(Y1(i,:), X1(i,:), T_X, T_Y);
        end
    end
end